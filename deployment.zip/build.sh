#!/bin/bash

echo "Build application bundle"
zip -r deployment.zip *