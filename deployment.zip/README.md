# Elastic Beanstalk Tips

* Deployment using Docker
* Circle CI integration
* Monitoring
* Logging
* Docker Private registry integration
* CloudWatch alarms
* Call-on-action with AWS Lambda

# Usage

* [Docker on Elastic Beanstalk Tips](http://www.blog.labouardy.com/elastic-beanstalk-docker-tips/)
